LaTeX project converted from 1.docx

Main file: main.tex
Compiler: XeLaTeX

Overleaf:
1. Upload the complete ZIP as a new project.
2. Select XeLaTeX in the project compiler settings.
3. Compile main.tex.

Local build:
    latexmk -xelatex -interaction=nonstopmode main.tex
Or run twice:
    xelatex main.tex

Keep the assets folder beside main.tex. It contains the original university logo.
The PDF supplied separately was compiled from this project.

Conversion notes:
- All three chapters, nine tables, and sixteen reference entries are included.
- Table of contents and section numbering are generated automatically.
- Misapplied Word heading styles have been converted to body text or lists.
- The duplicated 3.4 heading and stray heading-format markers were removed.
- Body wording, names, and reference content remain as supplied in the DOCX.
- The cover year is preserved as "2025-202"; confirm it before submission.
- References remain as in the uploaded document; this conversion does not
  replace them with the separately discussed IEEE reference revision.
